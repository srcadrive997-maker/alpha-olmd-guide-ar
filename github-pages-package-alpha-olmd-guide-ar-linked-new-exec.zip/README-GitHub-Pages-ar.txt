# GitHub Pages package

هذه الحزمة مربوطة مباشرة بالسكريبت الجديد:

https://script.google.com/macros/s/AKfycbwCskW3emelZHD7y1OZ5G8PrP0_AanVJmTfn8O6MEhfsRHJ4w612LIHuvRm6nfQQh87/exec

## ارفع إلى جذر المستودع
- index.html
- 404.html
- .nojekyll

## إعداد Pages
Settings > Pages
- Source = Deploy from a branch
- Branch = main
- Folder = /(root)

## الرابط المتوقع
https://srcadrive997-maker.github.io/alpha-olmd-guide-ar/
