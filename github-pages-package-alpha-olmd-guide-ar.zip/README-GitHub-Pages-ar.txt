# GitHub Pages package

ارفع محتويات هذا المجلد إلى جذر المستودع GitHub repository root.

## المطلوب
- index.html
- 404.html
- .nojekyll

## الإعداد داخل GitHub
1. افتح المستودع
2. Settings
3. Pages
4. Source = Deploy from a branch
5. Branch = main
6. Folder = /(root)

## رابط الموقع المتوقع
https://srcadrive997-maker.github.io/alpha-olmd-guide-ar/

## ملاحظات
- يجب أن يكون الملف الرئيسي اسمه index.html بالضبط
- إذا كان الرابط لا يعمل فورًا، انتظر دقيقة إلى دقيقتين ثم حدّث الصفحة
